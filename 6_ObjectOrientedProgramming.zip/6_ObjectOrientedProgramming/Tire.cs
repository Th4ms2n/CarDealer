class Tire{
    public int Size = 0;
    public Tire(int size = 10){
        this.Size = size;
    }
}
